import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import back from './back.svg';
//import Signup from './Signup';
class App extends Component {

  

  render() {
    return (
      <div className="App">
        <header className="App-header">
          
          <h2 className="App-title"><i class="fa fa-home">Whistle Blower</i></h2>
          <p><button class="App-signup"><i class="fa fa-user-plus">Sign Up</i></button></p>
          <p><button class="App-signin"><i class="fa fa-user">Sign In</i></button></p>
        </header>
        
        <img src={back} className="App-back" alt="img" />
        <p><button class="App-cont" onClick ><i class="fa fa-arrow-right"></i></button></p>
        <h1 className = "App-h">Whistle Blower</h1>
      </div>
      
    );
  }
}

export default App;
