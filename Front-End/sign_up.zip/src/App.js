import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Person from  './Person/Person'
import Particles from 'react-particles-js';

const particleOpt = {
    particles: {
        number: {
            value: 150,
            density: {
                enable: true,
                value_area: 800
            }
        }
    }
}

class App extends Component {
  render() {
    return (
      <div className="App">
         
         <p class="App-f">
      <Person name = {'Wallet No'}/>
      <Person name = {"Password"}></Person>
      <Person name = {"Confirm Password"} />
      </p>
      <Particles params = {particleOpt} />
      </div>
    );
  }
}

export default App;
