import React from 'react';

const person = (props) => 
{
    return (
        <div>
    <p>{props.name}</p>
    {props.children}
    <input type="text" value = {props.name}/>
     </div>
    )
}

export default  person;